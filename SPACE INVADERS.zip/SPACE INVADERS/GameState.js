﻿var GAME_STATE = 
{
	SPLASH   : 1,
	MAIN_MENU : 2,
	GAME : 3,
	LV2 : 4,
	LV3 : 5,
	GAME_OVER : 6,
	GAME_WON : 7,
	UPGRADES : 8,
	CREDITS : 9,
};
