vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Nov 2014 18:01:18 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|ALEXS\\TzL
vti_modifiedby:SR|ALEXS\\TzL
vti_timecreated:TR|30 Nov 2014 17:03:12 -0000
vti_backlinkinfo:VX|SPACE\\ INVADERS/game.html
vti_nexttolasttimemodified:TW|30 Nov 2014 17:17:48 -0000
vti_cacheddtm:TX|30 Nov 2014 17:17:48 -0000
vti_filesize:IR|285
