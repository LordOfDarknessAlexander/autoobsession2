vti_encoding:SR|utf8-nl
vti_author:SR|ALEXS\\TzL
vti_modifiedby:SR|ALEXS\\TzL
vti_timelastmodified:TR|01 Dec 2014 08:47:49 -0000
vti_timecreated:TR|30 Nov 2014 18:03:31 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|SPACE\\ INVADERS/game.html
vti_nexttolasttimemodified:TW|01 Dec 2014 08:47:45 -0000
vti_cacheddtm:TX|01 Dec 2014 08:47:49 -0000
vti_filesize:IR|160
